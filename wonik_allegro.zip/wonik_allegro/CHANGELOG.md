# Changelog – Allegro Hand V3 Description

All notable changes to this model will be documented in this file.

## [2023-05-18]
- Initial release.
